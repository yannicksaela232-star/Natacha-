package com.vipshop.ussd;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.provider.Settings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;
import android.widget.TextView;
import org.json.JSONObject;

/* Sistema: aparelho, licença, servidor e token. */
public class SistemaView extends ScrollView {
    public SistemaView(Context c) {
        super(c);
        setBackgroundColor(Color.BLACK);
        LinearLayout corpo = new LinearLayout(c);
        corpo.setOrientation(LinearLayout.VERTICAL);
        corpo.setPadding(UI.dp(c, 20), UI.dp(c, 12), UI.dp(c, 20), UI.dp(c, 20));
        addView(corpo);

        corpo.addView(UI.texto(c, "Sistema", 20, UI.OURO));

        LinearLayout perfil = UI.cartao(c);
        perfil.addView(UI.texto(c, "Licença", 11, UI.CINZA));
        perfil.addView(UI.texto(c, UI.tempoRestante(c), 16, UI.VERDE));
        corpo.addView(perfil);

        boolean acess = acessibilidadeAtiva(c);
        perfil.addView(UI.texto(c, "Acessibilidade (leitura do marcador)", 11, UI.CINZA));
        perfil.addView(UI.texto(c, acess ? "Ativa" : "Inativa", 13, acess ? UI.VERDE : UI.VERMELHO));
        Button ab = UI.botao(c, "ABRIR ACESSIBILIDADE");
        ab.setOnClickListener(v -> c.startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)));
        corpo.addView(ab);

        LinearLayout funcao = UI.cartao(c);
        funcao.addView(UI.texto(c, "🧭 Função deste telefone", 15, Color.WHITE));
        funcao.addView(UI.texto(c, "Atual: " + Papeis.nome(c), 13, UI.VERDE));
        String[][] opcoes = {{"📤 TELEFONE DE TRANSFERÊNCIA", Papeis.TRANSFERENCIA},
                {"💳 TELEFONE DE PAGAMENTO", Papeis.PAGAMENTO},
                {"🧩 TELEFONE ÚNICO (TUDO)", Papeis.UNICO}};
        for (String[] op : opcoes) {
            Button ob = UI.botao(c, op[0]);
            ob.setOnClickListener(v -> {
                Papeis.definir(c, op[1]);
                ((android.app.Activity) c).recreate();
            });
            funcao.addView(ob);
        }
        corpo.addView(funcao);

        LinearLayout automacao = UI.cartao(c);
        automacao.addView(UI.texto(c, "Automação", 15, Color.WHITE));
        TextView estadoBot = UI.texto(c, Config.botAtivo(c) ? "Estado: LIGADO" : "Estado: PAUSADO", 13,
                Config.botAtivo(c) ? UI.VERDE : UI.VERMELHO);
        automacao.addView(estadoBot);
        Button alternarBot = UI.botao(c, Config.botAtivo(c) ? "PAUSAR AUTOMAÇÃO" : "RETOMAR AUTOMAÇÃO");
        alternarBot.setOnClickListener(v -> {
            boolean novoEstado = !Config.botAtivo(c);
            Config.setBotAtivo(c, novoEstado);
            estadoBot.setText(novoEstado ? "Estado: LIGADO" : "Estado: PAUSADO");
            estadoBot.setTextColor(novoEstado ? UI.VERDE : UI.VERMELHO);
            alternarBot.setText(novoEstado ? "PAUSAR AUTOMAÇÃO" : "RETOMAR AUTOMAÇÃO");
            if (novoEstado && Config.pronto(c)) BridgeService.iniciar(c);
        });
        automacao.addView(alternarBot);
        automacao.addView(UI.texto(c, "Pausar impede o serviço de recolher novos pedidos. Uma transferência que já começou poderá terminar.", 11, UI.CINZA));
        corpo.addView(automacao);

        LinearLayout ativ = UI.cartao(c);
        ativ.addView(UI.texto(c, "🔑 Ativar este telefone", 15, Color.WHITE));
        ativ.addView(UI.texto(c, "Cola a chave do telefone (VIP-D-...). Cada chave só funciona uma vez.", 12, UI.CINZA));
        final EditText chaveDisp = new EditText(c);
        chaveDisp.setHint("VIP-D-...");
        chaveDisp.setTextColor(Color.WHITE);
        chaveDisp.setHintTextColor(Color.parseColor("#666666"));
        ativ.addView(chaveDisp);
        final TextView estadoDisp = UI.texto(c, "", 13, UI.CINZA);
        Button bDisp = UI.botao(c, "🔑 ATIVAR TELEFONE");
        bDisp.setOnClickListener(v -> ativarDispositivo(c, chaveDisp.getText().toString().trim(), estadoDisp));
        ativ.addView(bDisp);
        ativ.addView(estadoDisp);
        Button bVoz = UI.botao(c, "🎙️ ESCOLHER VOZ (FEMININA)");
        bVoz.setOnClickListener(x -> {
            final android.app.Activity act = (android.app.Activity) c;
            Voz.listarVozes(c, nomes -> act.runOnUiThread(() -> {
                if (nomes.isEmpty()) { Toast.makeText(c, "Não há vozes em português neste telemóvel.", Toast.LENGTH_LONG).show(); return; }
                String[] lista = nomes.toArray(new String[0]);
                new AlertDialog.Builder(c).setTitle("Escolhe a voz").setItems(lista, (d, i) -> {
                    Voz.guardarVoz(c, lista[i]);
                    Voz.falar(c, "Voz selecionada.");
                }).setNegativeButton("CANCELAR", null).show();
            }));
        });
        corpo.addView(bVoz);
        corpo.addView(ativ);

    }

    static boolean acessibilidadeAtiva(Context c) {
        String ativos = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return ativos != null && ativos.contains(c.getPackageName() + "/" + Acessibilidade.class.getName());
    }

    private void ativarDispositivo(Context c, String chave, TextView e) {
        if (!chave.startsWith("VIP-")) { e.setText("A chave começa por VIP-."); return; }
        e.setText("A ativar...");
        final String deviceId = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ANDROID_ID);
        final android.app.Activity act = (android.app.Activity) c;
        new Thread(() -> {
            try {
                JSONObject o = new JSONObject(Api.pedir(c, "POST", "/app/ativar", chave + " " + deviceId));
                if (o.optBoolean("ok") && "dispositivo".equals(o.optString("tipo"))) {
                    boolean tokenGuardado = Config.guardarTokenDispositivo(c, o.optString("token"));
                    if (!tokenGuardado) {
                        act.runOnUiThread(() -> e.setText("Não foi possível guardar o token com segurança."));
                        return;
                    }
                    Config.p(c).edit().putString("papel", o.optString("papel")).apply();
                    act.runOnUiThread(act::recreate);
                } else {
                    String msg = o.optString("erro", "chave inválida");
                    act.runOnUiThread(() -> e.setText("Erro: " + msg));
                }
            } catch (Exception ex) {
                String msg = ex.getMessage() == null ? "erro" : ex.getMessage();
                act.runOnUiThread(() -> e.setText("Erro: " + msg));
            }
        }).start();
    }

    private void pedirToken(Context c) {
        final EditText t = new EditText(c);
        t.setHint("Token do servidor");
        t.setText(Config.token(c));
        new AlertDialog.Builder(c)
                .setTitle("Token do servidor")
                .setView(t)
                .setPositiveButton("GUARDAR", (d, w) -> {
                    if (!Config.guardarToken(c, t.getText().toString().trim())) {
                        android.widget.Toast.makeText(c,
                                "Não foi possível guardar o token com segurança.",
                                android.widget.Toast.LENGTH_LONG).show();
                    } else if (Config.pronto(c)) {
                        BridgeService.iniciar(c);
                    }
                })
                .setNegativeButton("CANCELAR", null)
                .show();
    }
}
