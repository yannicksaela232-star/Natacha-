package com.vipshop.ussd;

import android.telecom.PhoneAccountHandle;
import android.telecom.TelecomManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.telephony.TelephonyManager;

import java.util.Locale;

/* Envio de megas: primeiro pela API do Android; se falhar, pela acessibilidade (como o MacroDroid). */
public class UssdEnvio {
    interface Fim { void correu(); }

    private final Context ctx;
    private final int slot;
    private final String codigo, quantidade, numero, restantes;
    private final Fim fim;
    private final Handler h = new Handler(Looper.getMainLooper());
    private int passos = 0;
    private boolean fechado = false;
    private boolean acess = false;

    UssdEnvio(Context ctx, int slot, String codigo, String quantidade, String numero, String restantes, Fim fim) {
        this.ctx = ctx;
        this.slot = slot;
        this.codigo = codigo;
        this.quantidade = quantidade;
        this.numero = numero;
        this.restantes = restantes;
        this.fim = fim;
    }

    void executar() {
        if (restantes != null && restantes.equals("0")) {
            fechar(false, "sem transferencias");
            return;
        }
        Voz.falar(ctx, "A transferir " + quantidade + " megabytes para " + Voz.digitos(numero) + ".");
        h.postDelayed(() -> fechar(false, "tempo esgotado"), 90000);
        h.post(() -> enviarApi("*162#"));
    }

    private void enviarApi(String texto) {
        try {
            TelephonyManager tm = Ussd.tm(ctx, slot);
            if (tm == null) { usarAcessibilidade(); return; }
            tm.sendUssdRequest(texto, new TelephonyManager.UssdResponseCallback() {
                @Override
                public void onReceiveUssdResponse(TelephonyManager t, String req, CharSequence resp) {
                    String r = proxima(resp == null ? "" : resp.toString());
                    if (r != null) enviarApi(r);
                }

                @Override
                public void onReceiveUssdResponseFailed(TelephonyManager t, String req, int falha) {
                    usarAcessibilidade();
                }
            }, h);
        } catch (Exception e) {
            usarAcessibilidade();
        }
    }

    /* Usa o SIM escolhido na app, para o Android não perguntar qual usar. */
    private void escolherSim(Intent i) {
        try {
            TelecomManager tc = (TelecomManager) ctx.getSystemService(Context.TELECOM_SERVICE);
            List<PhoneAccountHandle> contas = tc.getCallCapablePhoneAccounts();
            if (contas == null || contas.isEmpty()) return;
            PhoneAccountHandle escolhida = contas.get(Math.min(slot, contas.size() - 1));
            SubscriptionManager sm = (SubscriptionManager) ctx.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
            SubscriptionInfo info = sm.getActiveSubscriptionInfoForSimSlotIndex(slot);
            if (info != null) {
                for (PhoneAccountHandle h : contas) {
                    if (h.getId() != null && h.getId().contains(String.valueOf(info.getSubscriptionId()))) escolhida = h;
                }
            }
            i.putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, escolhida);
        } catch (Exception e) {
            /* sem SIM identificado: o Android pergunta, como antes */
        }
    }

    private void usarAcessibilidade() {
        if (fechado || acess) return;
        acess = true;
        passos = 0;
        Acessibilidade.reiniciar();
        Acessibilidade.ouvinte = this::proxima;
        try {
            Intent i = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode("*162#")));
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            escolherSim(i);
            ctx.startActivity(i);
        } catch (SecurityException e) {
            fechar(false, "sem permissao de chamadas");
        }
    }

    /* Sequência igual à do macro: *162# -> 8 (serviços) -> 2 (transferir) -> quantidade -> número -> OK. */
    private boolean enviouServico, enviouTransferir, enviouQuantidade, enviouNumero;

    private String proxima(String t) {
        if (fechado) return null;
        passos++;
        if (passos > 10) { fechar(false, "menu sem fim"); return null; }
        String n = t.toLowerCase(Locale.ROOT);
        if (n.contains("sucesso") || n.contains("transferid") || n.contains("conclu") || n.contains("permitida")) { fechar(true, t); return null; }
        if (n.contains("insuficiente") || n.contains("invalid") || n.contains("erro")) { fechar(false, t); return null; }
        if (!enviouServico && n.contains("servi")) { enviouServico = true; return "8"; }
        if (!enviouTransferir && n.contains("transfer")) { enviouTransferir = true; return "2"; }
        if (!enviouQuantidade && (n.contains("saldo") || n.contains("quantidade") || n.contains("megabyte") || n.contains("valor"))) { enviouQuantidade = true; return quantidade; }
        if (!enviouNumero && (n.contains("numero") || n.contains("número") || n.contains("destino"))) { enviouNumero = true; return numero; }
        if (n.contains("confirm") || n.contains("1. sim") || n.contains("1 - sim")) return "1";
        fechar(false, "menu desconhecido: " + t);
        return null;
    }

    private void fechar(boolean ok, String info) {
        if (fechado) return;
        fechado = true;
        h.removeCallbacksAndMessages(null);
        Acessibilidade.ouvinte = null;
        String fala;
        if (ok) {
            fala = (restantes != null && !restantes.isEmpty())
                    ? "Concluido. Restam " + restantes + " transferencias hoje."
                    : "Concluido.";
        } else if (info != null && info.startsWith("sem transferencias")) {
            fala = "Sem transferencias disponiveis hoje.";
        } else {
            fala = "Erro. Foi cancelado.";
        }
        Voz.falar(ctx, fala);
        String motivo = info == null ? "" : (info.length() > 80 ? info.substring(0, 80) : info);
        Api.enviarAsync(ctx, "POST", "/app/resultado?id=" + Ussd.enc(codigo) + "&ok=" + (ok ? "1" : "0") + "&motivo=" + Ussd.enc(motivo), null);
        if (fim != null) fim.correu();
    }
}
