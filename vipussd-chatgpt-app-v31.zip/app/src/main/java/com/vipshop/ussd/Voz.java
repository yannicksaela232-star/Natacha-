package com.vipshop.ussd;

import android.content.Context;
import android.speech.tts.TextToSpeech;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/* Voz do telemovel: anuncia as transferencias e os resultados. */
public class Voz {
    private static TextToSpeech tts;
    private static boolean pronto = false;
    private static final List<String> fila = new ArrayList<>();

    static synchronized void falar(Context c, String texto) {
        if (!Config.vozAtiva(c)) return;
        if (tts == null) {
            tts = new TextToSpeech(c.getApplicationContext(), status -> {
                synchronized (Voz.class) {
                    if (status == TextToSpeech.SUCCESS) {
                        int r = tts.setLanguage(new Locale("pt", "BR"));
                        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                            tts.setLanguage(new Locale("pt"));
                        }
                        String vn = Config.p(c).getString("voz_nome", "");
                        if (!vn.isEmpty()) for (android.speech.tts.Voice vz : tts.getVoices()) if (vz.getName().equals(vn)) tts.setVoice(vz);
                        pronto = true;
                        for (String t : fila) tts.speak(t, TextToSpeech.QUEUE_ADD, null, "v" + System.nanoTime());
                        fila.clear();
                    }
                }
            });
        }
        if (pronto) tts.speak(texto, TextToSpeech.QUEUE_ADD, null, "v" + System.nanoTime());
        else fila.add(texto);
    }

    /* Lista as vozes portuguesas instaladas no telemóvel. */
    static void listarVozes(Context c, java.util.function.Consumer<List<String>> depois) {
        final TextToSpeech[] caixa = new TextToSpeech[1];
        caixa[0] = new TextToSpeech(c.getApplicationContext(), status -> {
            List<String> nomes = new ArrayList<>();
            if (status == TextToSpeech.SUCCESS) {
                for (android.speech.tts.Voice vz : caixa[0].getVoices()) {
                    if (vz.getLocale().getLanguage().equals("pt")) nomes.add(vz.getName());
                }
            }
            depois.accept(nomes);
            caixa[0].shutdown();
        });
    }

    /* Guarda a voz escolhida e recria o motor para a aplicar. */
    static synchronized void guardarVoz(Context c, String nome) {
        Config.p(c).edit().putString("voz_nome", nome).apply();
        if (tts != null) tts.shutdown();
        tts = null;
        pronto = false;
    }

    /* 8536 -> "8 5 3 6" para a voz ler numero a numero */
    static String digitos(String n) {
        if (n == null) return "";
        StringBuilder sb = new StringBuilder();
        for (char ch : n.toCharArray()) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(ch);
        }
        return sb.toString();
    }
}
