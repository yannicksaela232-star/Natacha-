# VIPUssd v20.1 PRO (versão 2.1)

Projeto Android Java do VIPUssd, preparado para compilação no GitHub Actions.

## Requisitos
- JDK 17
- Gradle 8.4
- Android Gradle Plugin 8.1.4
- Android SDK 33

## Compilar localmente
```bash
gradle assembleDebug
```

APK de teste: `app/build/outputs/apk/debug/app-debug.apk`.

## Compilar no GitHub
1. Envie o conteúdo desta pasta para a raiz do repositório GitHub.
2. Abra a aba **Actions**.
3. Execute **VIPUssd v20.1 - Build APK** ou faça um `push`.
4. Descarregue o artefacto `VIPUssd-v20.1-debug-APK`.

## Alterações desta atualização
- Versão Android atualizada para `versionCode 21` e `versionName 2.1`.
- Tokens de servidor e de dispositivo passam a ser cifrados com AES-GCM e Android Keystore.
- Tokens guardados por versões anteriores são migrados automaticamente na primeira leitura, quando o Keystore está disponível.
- A cópia de segurança Android foi desativada para evitar restaurar tokens cifrados sem a chave local do Keystore.
- A API deixa de seguir redirecionamentos HTTP automaticamente, evitando encaminhar o cabeçalho de autenticação para outro destino.
- A fila liberta o bloqueio de operação se a inicialização de uma transferência falhar de forma síncrona.
- Mantidas as funções e os ecrãs existentes do projeto v20 PRO.

## Limitações que ainda exigem trabalho no servidor ou teste real
- O servidor predefinido ainda usa HTTP (`78.154.103.14:16701`). A cifragem local dos tokens não protege os dados durante o transporte. Para isso, é necessário configurar HTTPS/TLS no servidor e depois mudar o endereço da API.
- O telefone de transferência continua a usar o SIM 1 (slot 0). A seleção de SIM deve ser implementada e testada com o modelo de telefone e as operadoras usados.
- A confirmação final de transferências depende das mensagens USSD reais da operadora. Não se deve declarar sucesso apenas com base em mensagens genéricas; é necessário validar os textos reais.
- O APK Release produzido sem uma chave privada é `unsigned` e não deve ser usado para distribuição. O APK Debug é assinado com a chave de teste do Android e serve para instalação/testes.
- Esta atualização ainda precisa de compilação no GitHub Actions e de testes num telemóvel real antes de ser considerada pronta para produção.
