# VIPUssd v2.2 — automação nativa Android

Aplicação Android em Java. O projecto executa as rotinas USSD dentro do próprio VIPUssd, sem depender do MacroDroid.

## Funções incluídas no código
- Serviço em primeiro plano para consultar a fila do servidor e processar um pedido de cada vez.
- Envio USSD pela API de telefonia Android, com alternativa por Serviço de Acessibilidade quando a API falha.
- Leitura dos ecrãs USSD e preenchimento de menus compatíveis.
- Recepção de SMS de confirmação.
- Escolha de SIM 1 ou SIM 2 para os pedidos automáticos (conforme suporte do aparelho/operadora).
- Medição local do tempo de cada operação e resumo das últimas 20 operações.
- Tokens guardados com Android Keystore.

## Requisitos de compilação
- JDK 17
- Gradle 8.4
- Android Gradle Plugin 8.1.4
- Android SDK 33

## Compilar no GitHub Actions
1. Envie o conteúdo desta pasta para a raiz de um repositório GitHub.
2. Abra **Actions** e execute **VIPUssd v2.2 - Build APK** (ou faça push).
3. Descarregue o artefacto **VIPUssd-v2.2-debug-APK**.

## Importante antes de usar em produção
- O serviço de Acessibilidade tem de ser activado manualmente nas definições do Android.
- Conceda as permissões pedidas e teste primeiro com operações de baixo valor.
- A selecção do SIM 2 depende do suporte do aparelho e da operadora.
- A medição é do tempo total até à resposta USSD final, não da velocidade de dados móveis.
- O servidor configurado por defeito ainda usa HTTP; configure HTTPS no servidor antes de enviar dados reais.
- A compilação e os testes num telefone físico ainda precisam de ser executados.
