package com.vipshop.ussd;

import android.content.Context;
import android.graphics.Color;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

/* Aluguer por grupo: o dono define o ID do grupo e os dias (ou permanente). O bot bloqueia quando acaba. */
public class GruposView extends ScrollView {
    private final LinearLayout corpo;
    private final EditText campoId, campoDias;
    private final TextView estado;

    public GruposView(Context c) {
        super(c);
        setBackgroundColor(Color.BLACK);
        corpo = new LinearLayout(c);
        corpo.setOrientation(LinearLayout.VERTICAL);
        corpo.setPadding(UI.dp(c, 20), UI.dp(c, 12), UI.dp(c, 20), UI.dp(c, 20));
        addView(corpo);

        corpo.addView(UI.texto(c, "Grupos alugados", 20, UI.OURO));
        LinearLayout add = UI.cartao(c);
        add.addView(UI.texto(c, "Alugar um grupo", 15, Color.WHITE));
        add.addView(UI.texto(c, "ID do grupo (termina em @g.us)", 12, UI.CINZA));
        campoId = new EditText(c);
        campoId.setHint("ID@g.us");
        campoId.setTextColor(Color.WHITE);
        campoId.setHintTextColor(Color.parseColor("#666666"));
        add.addView(campoId);
        add.addView(UI.texto(c, "Dias de aluguer (ex: 10), ou escreve perm", 12, UI.CINZA));
        campoDias = new EditText(c);
        campoDias.setHint("10");
        campoDias.setTextColor(Color.WHITE);
        campoDias.setHintTextColor(Color.parseColor("#666666"));
        add.addView(campoDias);
        Button b = UI.botao(c, "ATIVAR ALUGUER");
        b.setOnClickListener(v -> ativar());
        add.addView(b);
        estado = UI.texto(c, "", 13, UI.CINZA);
        add.addView(estado);
        corpo.addView(add);

        carregar();
    }

    void carregar() {
        if (!Config.pronto(getContext())) {
            estado.setText("Falta o token: mantém o título VIP BOT pressionado e cola o token.");
            return;
        }
        new Thread(() -> {
            try {
                JSONArray arr = new JSONArray(Api.pedir(getContext(), "GET", "/app/grupos", null));
                post(() -> listar(arr));
            } catch (Exception e) {
                post(() -> estado.setText("Não foi possível carregar os grupos."));
            }
        }).start();
    }

    private void listar(JSONArray arr) {
        while (corpo.getChildCount() > 2) corpo.removeViewAt(corpo.getChildCount() - 1);
        if (arr.length() == 0) {
            corpo.addView(UI.texto(getContext(), "Ainda não há grupos alugados.", 13, UI.CINZA));
            return;
        }
        for (int i = 0; i < arr.length(); i++) {
            JSONObject g = arr.optJSONObject(i);
            if (g == null) continue;
            final String jid = g.optString("jid");
            final boolean ligado = g.optBoolean("ligado");
            boolean vencido = g.optBoolean("vencido");
            String expira = g.isNull("expira") ? "sem prazo" : ("permanente".equals(g.optString("expira"))
                    ? "permanente" : "expira " + g.optString("expira").substring(0, 10));
            LinearLayout caixa = UI.cartao(getContext());
            caixa.addView(UI.texto(getContext(), jid, 13, Color.WHITE));
            String situacao = vencido ? "Aluguer vencido" : (ligado ? "Ativo · " + expira : "Desligado · " + expira);
            int cor = vencido ? UI.VERMELHO : (ligado ? UI.VERDE : UI.CINZA);
            caixa.addView(UI.texto(getContext(), situacao, 13, cor));
            Button b = UI.botao(getContext(), ligado ? "DESLIGAR" : "LIGAR");
            b.setOnClickListener(v -> alterar(jid, ligado ? "off" : "on"));
            caixa.addView(b);
            corpo.addView(caixa);
        }
    }

    private void ativar() {
        String dias = campoDias.getText().toString().trim().toLowerCase();
        if (!dias.equals("perm") && !dias.matches("\\d+")) {
            estado.setText("Dias: escreve um número (ex: 10) ou perm.");
            return;
        }
        alterar(campoId.getText().toString().trim(), "on " + dias);
    }

    private void alterar(String jid, String resto) {
        if (!Config.pronto(getContext())) {
            estado.setText("Falta o token: mantém o título VIP BOT pressionado e cola o token.");
            return;
        }
        if (!jid.matches("\\S+@g\\.us")) {
            estado.setText("ID inválido. Deve terminar em @g.us.");
            return;
        }
        estado.setText("A guardar...");
        new Thread(() -> {
            try {
                String corpoPedido = jid + " " + resto;
                JSONObject o = new JSONObject(Api.pedir(getContext(), "POST", "/app/grupo", corpoPedido.trim()));
                post(() -> {
                    if (o.optBoolean("ok")) {
                        String exp = o.isNull("expira") ? "" : " Validade: " + o.optString("expira");
                        estado.setText("Guardado." + exp);
                    } else {
                        estado.setText("Erro: " + o.optString("erro"));
                    }
                    carregar();
                });
            } catch (Exception e) {
                post(() -> estado.setText("Sem ligação ao servidor."));
            }
        }).start();
    }
}
