package com.vipshop.ussd;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/* Converte megas em frases de voz e lê o saldo de um texto do *162#. */
public class Saldo {

    /* 300 -> "300 megas"; 1030 -> "1 giga e 6 megas"; 20000 -> "19 gigas e 544 megas"; 2048 -> "2 gigas" */
    static String formatar(long mb) {
        if (mb <= 0) return "sem megas";
        if (mb < 1024) return mb + " megas";
        long gb = mb / 1024;
        long resto = mb % 1024;
        String g = gb + (gb == 1 ? " giga" : " gigas");
        return resto == 0 ? g : g + " e " + resto + " megas";
    }

    /* Procura um valor com unidade (MB ou GB) no texto. Devolve megas inteiros, ou null. */
    static Long extrair(String t) {
        if (t == null) return null;
        Matcher m = Pattern.compile("(\\d{1,3}(?:[.,]\\d{3})+|\\d+(?:[.,]\\d+)?)\\s*(GB|MB)", Pattern.CASE_INSENSITIVE).matcher(t);
        if (!m.find()) return null;
        String num = m.group(1);
        boolean gb = m.group(2).equalsIgnoreCase("GB");
        double v;
        if (num.matches("\\d{1,3}([.,]\\d{3})+")) {
            v = Double.parseDouble(num.replaceAll("[.,]", ""));
        } else {
            v = Double.parseDouble(num.replace(',', '.'));
        }
        return Math.round(gb ? v * 1024 : v);
    }
}
