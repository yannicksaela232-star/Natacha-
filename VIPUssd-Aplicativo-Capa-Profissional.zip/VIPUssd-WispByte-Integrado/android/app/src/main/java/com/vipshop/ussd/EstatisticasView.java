package com.vipshop.ussd;

import android.content.Context;
import android.graphics.Color;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

/* Lucro e estatísticas: lucro de hoje, 7 dias e tabela de lucro por pacote. */
public class EstatisticasView extends ScrollView {
    private final LinearLayout corpo;
    private final EditText campoMb, campoLucro;
    private final TextView estado;

    public EstatisticasView(Context c) {
        super(c);
        setBackgroundColor(Color.parseColor("#0B1220"));
        corpo = new LinearLayout(c);
        corpo.setOrientation(LinearLayout.VERTICAL);
        corpo.setPadding(UI.dp(c, 20), UI.dp(c, 16), UI.dp(c, 20), UI.dp(c, 20));
        addView(corpo);

        corpo.addView(UI.texto(c, "📊 Lucro e estatísticas", 20, UI.OURO));

        LinearLayout form = UI.cartao(c);
        form.addView(UI.texto(c, "🧾 Tabela de lucro por pacote", 14, Color.WHITE));
        campoMb = new EditText(c);
        campoMb.setHint("MB (ex: 220)");
        campoMb.setTextColor(Color.WHITE);
        campoMb.setHintTextColor(Color.parseColor("#666666"));
        form.addView(campoMb);
        campoLucro = new EditText(c);
        campoLucro.setHint("Lucro em MT (ex: 2)");
        campoLucro.setTextColor(Color.WHITE);
        campoLucro.setHintTextColor(Color.parseColor("#666666"));
        form.addView(campoLucro);
        Button g = UI.botao(c, "💾 GUARDAR NA TABELA");
        g.setOnClickListener(v -> guardar());
        form.addView(g);
        estado = UI.texto(c, "", 13, UI.CINZA);
        form.addView(estado);
        corpo.addView(form);

        carregar();
    }

    private void carregar() {
        if (!Config.pronto(getContext())) {
            estado.setText("🔒 Falta o token. Abre SISTEMA e cola o token.");
            return;
        }
        new Thread(() -> {
            try {
                JSONObject o = new JSONObject(Api.pedir(getContext(), "GET", "/app/lucro", null));
                post(() -> mostrar(o));
            } catch (Exception e) {
                String msg = e.getMessage() == null ? "erro desconhecido" : e.getMessage();
                post(() -> estado.setText("⚠️ " + msg));
            }
        }).start();
    }

    private void mostrar(JSONObject o) {
        while (corpo.getChildCount() > 2) corpo.removeViewAt(corpo.getChildCount() - 1);
        Context c = getContext();

        LinearLayout resumo = UI.cartao(c);
        resumo.addView(UI.texto(c, "💰 Lucro de hoje", 12, UI.CINZA));
        resumo.addView(UI.texto(c, o.optInt("hoje") + " MT", 24, UI.VERDE));
        resumo.addView(UI.texto(c, "📅 Total dos últimos 7 dias: " + o.optInt("total7") + " MT", 13, Color.WHITE));
        corpo.addView(resumo);

        LinearLayout grafico = UI.cartao(c);
        grafico.addView(UI.texto(c, "📈 Lucro por dia", 14, Color.WHITE));
        JSONArray dias = o.optJSONArray("dias");
        int max = 1;
        if (dias != null) for (int i = 0; i < dias.length(); i++) max = Math.max(max, dias.optJSONObject(i).optInt("total"));
        if (dias != null) {
            for (int i = 0; i < dias.length(); i++) {
                JSONObject d = dias.optJSONObject(i);
                int total = d.optInt("total");
                int barras = total == 0 ? 0 : Math.max(1, total * 20 / max);
                StringBuilder sb = new StringBuilder();
                for (int k = 0; k < barras; k++) sb.append("█");
                String dia = d.optString("dia");
                String rotulo = dia.length() >= 10 ? dia.substring(8, 10) + "/" + dia.substring(5, 7) : dia;
                grafico.addView(UI.texto(c, rotulo + "  " + sb + "  " + total + " MT", 12, UI.VERDE));
            }
        }
        corpo.addView(grafico);

        LinearLayout tabela = UI.cartao(c);
        tabela.addView(UI.texto(c, "📦 Pacotes e lucro", 14, Color.WHITE));
        JSONArray t = o.optJSONArray("tabela");
        if (t == null || t.length() == 0) {
            tabela.addView(UI.texto(c, "Ainda não há pacotes na tabela.", 12, UI.CINZA));
        } else {
            for (int i = 0; i < t.length(); i++) {
                JSONObject p = t.optJSONObject(i);
                if (p == null) continue;
                int mb = p.optInt("mb");
                String tam = mb >= 1024 ? (mb / 1024) + " GB" : mb + " MB";
                tabela.addView(UI.texto(c, tam + "  →  " + p.optDouble("lucro") + " MT de lucro", 13, Color.WHITE));
            }
        }
        corpo.addView(tabela);
        estado.setText("");
    }

    private void guardar() {
        String mb = campoMb.getText().toString().trim();
        String lucro = campoLucro.getText().toString().trim().replace(',', '.');
        if (!mb.matches("\\d+") || !lucro.matches("\\d+(\\.\\d+)?")) {
            estado.setText("Escreve os MB (só números) e o lucro em MT.");
            return;
        }
        if (!Config.pronto(getContext())) {
            estado.setText("🔒 Falta o token. Abre SISTEMA e cola o token.");
            return;
        }
        estado.setText("A guardar...");
        new Thread(() -> {
            try {
                JSONObject o = new JSONObject(Api.pedir(getContext(), "POST", "/app/lucro", mb + " " + lucro));
                post(() -> {
                    if (o.optBoolean("ok")) { estado.setText("✅ Guardado."); carregar(); }
                    else estado.setText("⚠️ " + o.optString("erro"));
                });
            } catch (Exception e) {
                String msg = e.getMessage() == null ? "erro desconhecido" : e.getMessage();
                post(() -> estado.setText("⚠️ " + msg));
            }
        }).start();
    }
}
