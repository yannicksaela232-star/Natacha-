package com.vipshop.ussd;

import android.content.Context;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/* Chamadas ao servidor do bot. Todas levam o token no cabeçalho X-Token. */
public class Api {
    static String pedir(Context c, String metodo, String caminho, String corpo) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(Config.servidor(c) + caminho).openConnection();
        con.setRequestMethod(metodo);
        con.setConnectTimeout(8000);
        con.setReadTimeout(20000);
        con.setUseCaches(false);
        // Não seguir redirecionamentos automaticamente: o cabeçalho X-Token
        // não deve ser encaminhado para outro host sem validação.
        con.setInstanceFollowRedirects(false);
        con.setRequestProperty("Accept", "application/json, text/plain, */*");
        if (!Config.token(c).isEmpty()) con.setRequestProperty("X-Token", Config.token(c));
        con.setRequestProperty("Content-Type", "text/plain; charset=UTF-8");
        try {
            if (corpo != null) {
                con.setDoOutput(true);
                try (OutputStream os = con.getOutputStream()) {
                    os.write(corpo.getBytes("UTF-8"));
                    os.flush();
                }
            }
            int code = con.getResponseCode();
            InputStream stream = code >= 300 ? con.getErrorStream() : con.getInputStream();
            StringBuilder sb = new StringBuilder();
            if (stream != null) {
                try (InputStream is = stream;
                     BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
                    String linha;
                    while ((linha = br.readLine()) != null) sb.append(linha);
                }
            }
            if (code < 200 || code >= 300) throw new Exception("HTTP " + code + " " + sb);
            return sb.toString();
        } finally {
            con.disconnect();
        }
    }

    static void enviarAsync(Context c, String metodo, String caminho, String corpo) {
        new Thread(() -> {
            try {
                pedir(c, metodo, caminho, corpo);
            } catch (Exception e) {
                Log.e("VIP", "api " + caminho + ": " + e.getMessage());
            }
        }).start();
    }
}
