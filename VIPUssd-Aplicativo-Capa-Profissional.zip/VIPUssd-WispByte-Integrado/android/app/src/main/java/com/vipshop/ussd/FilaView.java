package com.vipshop.ussd;

import android.content.Context;
import android.graphics.Color;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

/* Fila de envios ao vivo: contadores e linhas por pedido, no estilo da fila do bot. */
public class FilaView extends ScrollView {
    private final LinearLayout corpo;

    public FilaView(Context c) {
        super(c);
        setBackgroundColor(Color.parseColor("#0A0A0A"));
        corpo = new LinearLayout(c);
        corpo.setOrientation(LinearLayout.VERTICAL);
        corpo.setPadding(UI.dp(c, 20), UI.dp(c, 16), UI.dp(c, 20), UI.dp(c, 20));
        addView(corpo);
        carregar();
    }

    private TextView titulo(Context c) {
        String a = "AUTO BOT", b = " AUTOMÁTICO";
        SpannableString s = new SpannableString(a + b);
        s.setSpan(new ForegroundColorSpan(Color.parseColor("#E11D48")), 0, a.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        s.setSpan(new ForegroundColorSpan(Color.WHITE), a.length(), a.length() + b.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(20);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setPadding(0, 0, 0, UI.dp(c, 4));
        return t;
    }

    private void carregar() {
        if (!Config.pronto(getContext())) {
            mostrar(null, "Falta o token. Abre SISTEMA e cola o token.");
            return;
        }
        new Thread(() -> {
            try {
                JSONArray arr = new JSONArray(Api.pedir(getContext(), "GET", "/app/fila", null));
                post(() -> mostrar(arr, null));
            } catch (Exception e) {
                String msg = e.getMessage() == null ? "erro desconhecido" : e.getMessage();
                post(() -> mostrar(null, "Erro: " + msg));
            }
        }).start();
    }

    private void mostrar(JSONArray arr, String erro) {
        Context c = getContext();
        corpo.removeAllViews();
        corpo.addView(titulo(c));
        corpo.addView(UI.texto(c, "Fila de envios ao vivo", 12, UI.CINZA));

        if (erro != null) {
            corpo.addView(UI.texto(c, erro, 13, UI.VERMELHO));
            return;
        }

        int pend = 0, env = 0, err = 0;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject p = arr.optJSONObject(i);
            if (p == null) continue;
            String e = p.optString("estado");
            if (e.equals("pendente")) pend++;
            else if (e.equals("enviando")) env++;
            else if (e.equals("erro")) err++;
        }

        LinearLayout contadores = new LinearLayout(c);
        contadores.setOrientation(LinearLayout.HORIZONTAL);
        contadores.addView(contador(c, String.valueOf(pend), "NA FILA", "#FFB62E"));
        contadores.addView(contador(c, String.valueOf(env), "A ENVIAR", "#22C55E"));
        contadores.addView(contador(c, String.valueOf(err), "AGUARDAR", "#E11D48"));
        corpo.addView(contadores);

        if (arr.length() == 0) {
            LinearLayout vazio = UI.cartao(c);
            vazio.addView(UI.texto(c, "FILA VAZIA NO MOMENTO", 16, Color.WHITE));
            vazio.addView(UI.texto(c, "Nenhum pedido está a ser atendido.", 13, UI.CINZA));
            corpo.addView(vazio);
            return;
        }

        for (int i = 0; i < arr.length(); i++) {
            JSONObject p = arr.optJSONObject(i);
            if (p == null) continue;
            String e = p.optString("estado");
            String estado, cor;
            if (e.equals("enviando")) { estado = "A ENVIAR"; cor = "#22C55E"; }
            else if (e.equals("erro")) { estado = "ERRO"; cor = "#E11D48"; }
            else { estado = "NA FILA"; cor = "#FFB62E"; }

            long data = p.optLong("data", 0);
            long min = data > 0 ? Math.max(0, (System.currentTimeMillis() - data) / 60000) : 0;
            String espera = min >= 60 ? "Há " + (min / 60) + " h e " + (min % 60) + " min" : "Há " + min + " min";

            int mb = p.optInt("mb");
            String tamanho = mb >= 1024 ? (mb / 1024) + " GB" : mb + " MB";

            LinearLayout linha = UI.cartao(c);
            LinearLayout topo = new LinearLayout(c);
            topo.setOrientation(LinearLayout.HORIZONTAL);
            TextView num = UI.texto(c, p.optString("numero", "-"), 18, Color.WHITE);
            num.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            topo.addView(num);
            topo.addView(UI.texto(c, tamanho, 18, Color.parseColor("#FFB62E")));
            linha.addView(topo);
            linha.addView(UI.texto(c, espera, 12, UI.CINZA));
            linha.addView(UI.texto(c, estado, 12, Color.parseColor(cor)));
            corpo.addView(linha);
        }
    }

    private LinearLayout contador(Context c, String valor, String rotulo, String cor) {
        LinearLayout caixa = UI.cartao(c);
        caixa.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView v = UI.texto(c, valor, 26, Color.parseColor(cor));
        v.setGravity(android.view.Gravity.CENTER);
        TextView r = UI.texto(c, rotulo, 10, UI.CINZA);
        r.setGravity(android.view.Gravity.CENTER);
        caixa.addView(v);
        caixa.addView(r);
        return caixa;
    }
}
