package com.vipshop.ussd;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;
import org.json.JSONArray;

/** Medições locais de duração das operações USSD. */
final class SpeedStats {
    private static final String PREF = "speed_stats";
    private SpeedStats() {}

    static long iniciar() { return SystemClock.elapsedRealtime(); }

    static void terminar(Context c, long inicio, boolean sucesso) {
        if (inicio <= 0) return;
        long ms = Math.max(0, SystemClock.elapsedRealtime() - inicio);
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        JSONArray a;
        try { a = new JSONArray(p.getString("tempos", "[]")); }
        catch (Exception e) { a = new JSONArray(); }
        a.put(ms);
        while (a.length() > 20) a.remove(0);
        int total = p.getInt("total", 0) + 1;
        int ok = p.getInt("sucessos", 0) + (sucesso ? 1 : 0);
        p.edit().putString("tempos", a.toString()).putInt("total", total)
                .putInt("sucessos", ok).putLong("ultimo_ms", ms).apply();
    }

    static String resumo(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        JSONArray a;
        try { a = new JSONArray(p.getString("tempos", "[]")); }
        catch (Exception e) { a = new JSONArray(); }
        if (a.length() == 0) return "Ainda sem medições locais.";
        long soma = 0;
        for (int i = 0; i < a.length(); i++) soma += a.optLong(i, 0);
        double media = soma / (double) a.length() / 1000.0;
        double ultimo = p.getLong("ultimo_ms", 0) / 1000.0;
        return String.format(java.util.Locale.getDefault(),
                "Média local (%d operações): %.1f s\nÚltima operação: %.1f s\nConcluídas: %d de %d",
                a.length(), media, ultimo, p.getInt("sucessos", 0), p.getInt("total", 0));
    }
}
