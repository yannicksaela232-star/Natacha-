package com.vipshop.ussd;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.telephony.TelephonyManager;

import java.util.Locale;

/* Transferência de crédito: *111# -> 10 (Serviços) -> 4 (Transferir crédito) -> "valor numero". */
public class CreditoUssd {
    private final Context ctx;
    private final int slot;
    private final String valor, numero;
    private final Handler h = new Handler(Looper.getMainLooper());
    private int passo = 0;
    private boolean fechado = false;

    CreditoUssd(Context ctx, int slot, String valor, String numero) {
        this.ctx = ctx;
        this.slot = slot;
        this.valor = valor;
        this.numero = numero;
    }

    void executar() {
        Voz.falar(ctx, "A transferir " + valor + " meticais para " + Voz.digitos(numero) + ".");
        h.postDelayed(() -> fechar(null, "tempo esgotado"), 90000);
        h.post(() -> enviar("*111#"));
    }

    private void enviar(String texto) {
        try {
            TelephonyManager tm = Ussd.tm(ctx, slot);
            if (tm == null) { fechar(null, "SIM nao encontrado"); return; }
            tm.sendUssdRequest(texto, new TelephonyManager.UssdResponseCallback() {
                @Override
                public void onReceiveUssdResponse(TelephonyManager t, String req, CharSequence resp) {
                    tratar(resp == null ? "" : resp.toString());
                }

                @Override
                public void onReceiveUssdResponseFailed(TelephonyManager t, String req, int falha) {
                    fechar(null, "falha USSD " + falha);
                }
            }, h);
        } catch (Exception e) {
            fechar(null, "erro: " + e.getMessage());
        }
    }

    private void tratar(String t) {
        if (fechado) return;
        String n = t.toLowerCase(Locale.ROOT);
        passo++;
        if (passo == 1) {
            if (n.contains("servicos") || n.contains("soprati")) enviar("10");
            else fechar(null, "menu principal inesperado");
            return;
        }
        if (passo == 2) {
            if (n.contains("transferir")) enviar("4");
            else fechar(null, "submenu inesperado");
            return;
        }
        if (passo == 3) {
            if (n.contains("valor") || n.contains("destino")) enviar(valor + " " + numero);
            else fechar(null, "pedido de valor inesperado");
            return;
        }
        fechar(t, null);
    }

    private void fechar(String resposta, String erro) {
        if (fechado) return;
        fechado = true;
        h.removeCallbacksAndMessages(null);
        if (resposta != null) {
            Voz.falar(ctx, "Resposta da operadora recebida.");
        } else {
            Voz.falar(ctx, "Erro na transferencia de credito. " + (erro == null ? "" : erro));
        }
    }
}
