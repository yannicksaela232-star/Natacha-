package com.vipshop.ussd;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import android.util.Log;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

/** Guarda tokens cifrados com uma chave protegida pelo Android Keystore. */
final class SecureTokenStore {
    private static final String TAG = "VIP_TOKEN";
    private static final String ALIAS = "vipussd_token_key_v1";
    private static final String SUFFIX = "_encrypted_v1";
    private static final int GCM_TAG_BITS = 128;

    private SecureTokenStore() { }

    static synchronized String get(Context context, String name) {
        SharedPreferences prefs = Config.p(context);
        String encrypted = prefs.getString(name + SUFFIX, null);
        if (encrypted != null) {
            try {
                return decrypt(encrypted);
            } catch (Exception e) {
                // Não devolver nem recriar um token cifrado que já não possa ser aberto.
                Log.e(TAG, "Não foi possível abrir o token guardado.", e);
                return "";
            }
        }

        // Migração transparente dos tokens guardados pelas versões anteriores.
        String legado = prefs.getString(name, "");
        if (legado == null || legado.isEmpty()) return "";
        if (put(context, name, legado)) return legado;
        // Mantém compatibilidade se o dispositivo não permitir usar o Keystore.
        return legado;
    }

    static synchronized boolean put(Context context, String name, String value) {
        SharedPreferences prefs = Config.p(context);
        if (value == null || value.isEmpty()) {
            return prefs.edit().remove(name).remove(name + SUFFIX).commit();
        }
        try {
            String cifrado = encrypt(value);
            return prefs.edit().putString(name + SUFFIX, cifrado).remove(name).commit();
        } catch (Exception e) {
            Log.e(TAG, "Não foi possível proteger o token no Android Keystore.", e);
            return false;
        }
    }

    private static SecretKey getOrCreateKey() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        java.security.Key existing = store.getKey(ALIAS, null);
        if (existing instanceof SecretKey) return (SecretKey) existing;

        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build();
        generator.init(spec);
        return generator.generateKey();
    }

    private static String encrypt(String value) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
        byte[] iv = cipher.getIV();
        byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        ByteBuffer buffer = ByteBuffer.allocate(1 + iv.length + encrypted.length);
        buffer.put((byte) iv.length);
        buffer.put(iv);
        buffer.put(encrypted);
        return Base64.encodeToString(buffer.array(), Base64.NO_WRAP);
    }

    private static String decrypt(String encoded) throws Exception {
        byte[] payload = Base64.decode(encoded, Base64.NO_WRAP);
        if (payload.length < 14) throw new IllegalArgumentException("Token cifrado inválido");
        ByteBuffer buffer = ByteBuffer.wrap(payload);
        int ivLength = buffer.get() & 0xff;
        if (ivLength < 12 || ivLength > 16 || buffer.remaining() <= ivLength) {
            throw new IllegalArgumentException("Dados cifrados inválidos");
        }
        byte[] iv = new byte[ivLength];
        buffer.get(iv);
        byte[] encrypted = new byte[buffer.remaining()];
        buffer.get(encrypted);

        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(GCM_TAG_BITS, iv));
        return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
    }
}
